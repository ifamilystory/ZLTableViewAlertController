//
//  TestViewController.h
//  ZLTableViewAlertController
//
//  Created by Zhangling on 2016/11/27.
//  Copyright © 2016年 Rippleinfo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController
- (IBAction)alertAction:(UIButton *)sender;
- (IBAction)actionSheetAction:(UIButton *)sender;
- (IBAction)notificationAlertAction:(UIButton *)sender;
@end
